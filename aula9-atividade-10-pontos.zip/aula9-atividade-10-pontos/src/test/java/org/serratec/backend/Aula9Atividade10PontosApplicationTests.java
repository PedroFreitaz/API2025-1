package org.serratec.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula9Atividade10PontosApplicationTests {

	@Test
	void contextLoads() {
	}

}
