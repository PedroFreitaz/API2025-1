package org.serratec.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula9Atividade10PontosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula9Atividade10PontosApplication.class, args);
	}

}
