package org.serratec.backend.exception;

public class LancamentoVendasException extends RuntimeException{
	public LancamentoVendasException(String message) {
		super(message);
	}
}
